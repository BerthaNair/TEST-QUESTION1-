/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingcosolereport_question1;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class GamingCosoleReport_Question1 {

    public static void main(String[] args) {
        // CREATING A SCANNER CLASS 
               
        // declaring the variables 
        String city[] = {"Cape Town", "Port Elizabeth", "Pretoria"};
        int [][] sales = {{1000, 2000, 3000},
                         {2000, 3000, 4000},
                         {1500, 1100, 1200}};
          String gamingConsoles[] = { "PS5", "XBOX", "SWITCH"};
          int[] monthlyTotal = new int[3];
           int[] total = new int[3];
          
           //PRINT SALES REPORT HEADING
        System.out.println("**********************************");
        System.out.println("GAMING CONSOLE REPORT");
        System.out.println("**********************************");
        
        System.out.print("\t\t");
        
        //HEADER FOR THE GAMING CONSOLES
       for(int x=0; x<gamingConsoles.length; x++){
            System.out.print(gamingConsoles[x] + "\t");
            
        }
        System.out.println();
        
         //sales data
        for(int x=0; x<sales.length; x++){
              System.out.print(city[x] + "\t");
              
              for(int y =0 ; y<sales[x].length; y++){
                     total[x] +=sales[x][y];
              System.out.print(sales[x][y] + "\t");
              }
              System.out.println();
        }
         System.out.println("**********************************");
        System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
        System.out.println("**********************************");
        
        
          
          for (int x = 0; x<sales.length; x++){
              int tv =0;
              monthlyTotal[x] = sales[0][x] + sales[1][x] + sales[2][x];
              
              System.out.print("\t" + monthlyTotal[x]);
                    
        
            }
            
          
          
        }
        
    }


